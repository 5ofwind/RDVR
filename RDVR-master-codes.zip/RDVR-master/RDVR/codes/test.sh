python3 test.py -opt options/test/test_RDVR_Vid4.yml

python3 test.py -opt options/test/test_RDVR_UDM10.yml

python3 test_vimeo.py -opt options/test/test_RDVR_Vimeo90K.yml